__MODULE__ = "Stickers"
__HELP__ = """
Bantuan Untuk Stickers

• Perintah: <code>{0}kang</code> [reply to image/sticker]
• Penjelasan: Balas Ke Sticker Atau Gambar Untuk Menambahkan Ke Sticker Pack.

<b>Note:</b> Untuk Membuat Sticker Pack baru Gunakan angka dibelakang !kang.
<b>Contoh:</b> <code>kang 2</code> untuk membuat dan menyimpan ke sticker pack ke 2
"""
