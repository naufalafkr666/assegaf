__MODULE__ = "Meme"
__HELP__ = """
Bantuan Untuk Meme

• Perintah: <code>{0}memes</code> [text]
• Penjelasan: Untuk membuat stiker memes random.
"""
