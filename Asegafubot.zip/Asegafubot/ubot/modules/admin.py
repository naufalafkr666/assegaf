__MODULE__ = "Admin"
__HELP__ = """
Bantuan Untuk Admin

• Perintah: <code>{0}kick or dkick</code> [user_id/username/reply user]
• Penjelasan: Untuk menendang anggota dari grup.

• Perintah: <code>{0}ban or dban </code> [user_id/username/reply user]
• Penjelasan: Untuk memblokir anggota dari grup.

• Perintah: <code>{0}mute</code> [user_id/username/reply user]
• Penjelasan: Untuk membisukan anggota dari grup.

• Perintah: <code>{0}unban</code> [user_id/username/reply user]
• Penjelasan: Untuk melepas pemblokiran anggota dari grup.

• Perintah: <code>{0}unmute</code> [user_id/username/reply user]
• Penjelasan: Untuk melepas pembisuan anggota dari grup.
"""
