__MODULE__ = "Asupan"
__HELP__ = """
Bantuan Untuk Asupan

• Perintah:  <code>{0}asupan</code>
• Penjelasan:  Untuk mengirim video asupan random.

• Perintah: <code>{0}bokep</code>
• Penjelasan: Untuk mengirim video bokep random.

• Perintah:  <code>{0}cewe</code>
• Penjelasan:  Untuk mengirim photo cewek random.

• Perintah: <code>{0}cowo</code>
• Penjelasan: Untuk mengirim photo cowok random.

• Perintah:  <code>{0}anime</code>
• Penjelasan:  Untuk mengirim photo anime random.

• Perintah: <code>{0}anime2</code>
• Penjelasan: Untuk mengirim photo anime random.

• Perintah:  <code>{0}pap</code>
• Penjelasan:  Untuk mengirim photo pap random.
"""
